<?php
    $conn = mysqli_connect('localhost','root','','mps') or die ('I cannot connect to the datebase because: ' . mysql_error());;
    if($conn == false)
        {echo "Not Connected";}
    else
    {echo "";}
?>